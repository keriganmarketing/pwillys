<?php
define("ACCESS_KEY", "bf59b0e14faa8186e156ece028f86970");
?>

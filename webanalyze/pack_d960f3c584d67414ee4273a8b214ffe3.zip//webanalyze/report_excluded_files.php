<?php die(); ?>
/wp-content/plugins/wordpress-seo/js/dist/components-950.min.js
/wp-content/plugins/wordpress-seo/js/dist/wp-seo-analysis-worker-950.min.js
/wp-content/plugins/wordpress-seo/js/dist/analysis-950.min.js
